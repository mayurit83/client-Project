# Client & Project Management System
A full-stack web application for managing clients and projects.