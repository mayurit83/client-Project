import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Client & Project Management System</h1>
    </div>
  );
}

export default App;
